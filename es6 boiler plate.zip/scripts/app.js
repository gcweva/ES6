//export var appControllers = angular.module('appControllers', []);
//export var appRouter = angular.module('appRouter', ['ngRoute', appControllers.name]);
export var app = angular.module('predixApp', ['ngRoute']);

#ES6 AngularJS Boilerplate
This project is an example of using ECMA 6 with AngularJS.
